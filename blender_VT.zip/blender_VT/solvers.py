from math import pi

vowels = ['a', 'i', 'u', 'e', 'o']
jvowels = ['あ', 'い', 'う', 'え', 'お']

# Normalization of targets.
# This stuff is calculated by the "calibrate vowels" in the tracker.py that is implemented for OFS.
# It is not calibratable here but maybe it should be?
normalizations = {
    'a': 1.534770823748702,
    'i': 2,
    'u': 4.294774692471924,
    'e': 2.3366845158182037,
    'o': 2
}

# Calibration targets for ARKit to vowel shapes.
vowel_targets = {
    "a": [0.6, 0.5],
    "i": [0.1, 0.7],
    "u": [0.2, -0.1],
    "e": [0.3, 0.6],
    "o": [0.6, -0.1]
}

def clamp(val, min_val, max_val):
    return max(min(val, max_val), min_val)

def remap(value, old_min, old_max, new_min, new_max):
    normalized_value = (value - old_min) / (old_max - old_min)
    return normalized_value * (new_max - new_min) + new_min

def solve_vowels(mouthX, mouthY):
    ratioI = clamp(remap(mouthX, 0, 1, 0, 1) * 2 * remap(mouthY, 0, 1, 0.2, 0.7), 0, 1)
    ratioA = mouthY * 0.4 + mouthY * (1 - ratioI) * 0.6
    ratioU = mouthY * remap(1 - ratioI, 0, 1, 0, 0.3) * 0.1
    ratioE = remap(ratioU, 0, 1, 0.2, 1) * (1 - ratioI) * 0.3
    ratioO = (1 - ratioI) * remmap(mouthY, 0, 1, 0.3, 1) * 0.4

    return [ratioA, ratioI, ratioU, ratioE, ratioO]

def get_vowel_score(target, sample, normalization):
    rx = (sample[0] - target[0]) ** 2
    ry = (sample[1] - target[1]) ** 2

    return 1 - (clamp(rx + ry, 0, 1) ** 0.5) * normalization

def arkit_to_vowels(shapekeys):
    s = {}
    r = {}
    for k in shapekeys:
        s[k["k"]] = k["v"]

    # Calculate mouth open and wide values
    mo = s["jawOpen"]
    mw = max(s["mouthDimpleLeft"], s["mouthDimpleRight"]) * 5 - s["mouthPucker"]

    # Initialize all ARKit blend shapes
    arkit_shapes = [
        "browInnerUp", "browDownLeft", "browDownRight", "browOuterUpLeft", "browOuterUpRight",
        "eyeLookUpLeft", "eyeLookUpRight", "eyeLookDownLeft", "eyeLookDownRight",
        "eyeLookInLeft", "eyeLookInRight", "eyeLookOutLeft", "eyeLookOutRight",
        "eyeBlinkLeft", "eyeBlinkRight", "eyeSquintRight", "eyeSquintLeft",
        "eyeWideLeft", "eyeWideRight", "cheekPuff", "cheekSquintLeft", "cheekSquintRight",
        "noseSneerLeft", "noseSneerRight", "jawOpen", "jawForward", "jawLeft", "jawRight",
        "mouthFunnel", "mouthPucker", "mouthLeft", "mouthRight", "mouthRollUpper",
        "mouthRollLower", "mouthShrugUpper", "mouthShrugLower", "mouthClose",
        "mouthSmileLeft", "mouthSmileRight", "mouthFrownLeft", "mouthFrownRight",
        "mouthDimpleLeft", "mouthDimpleRight", "mouthUpperUpLeft", "mouthUpperUpRight",
        "mouthLowerDownLeft", "mouthLowerDownRight", "mouthPressLeft", "mouthPressRight",
        "mouthStretchLeft", "mouthStretchRight"
    ]
    
    # Set all ARKit blend shapes
    for shape_name in arkit_shapes:
        r[shape_name] = s.get(shape_name, 0.0)

    # Initialize vowels
    for vowel in vowels:
        r[vowel] = 0.0
        r[jvowels[vowels.index(vowel)]] = 0.0

    scores = [0, 0, 0, 0, 0]

    # Calculate vowel scores
    scores[0] = get_vowel_score(vowel_targets["a"], [mo, mw], normalizations["a"])
    scores[1] = get_vowel_score(vowel_targets["i"], [mo, mw], normalizations["i"])
    scores[2] = get_vowel_score(vowel_targets["u"], [mo, mw], normalizations["u"])
    scores[3] = get_vowel_score(vowel_targets["e"], [mo, mw], normalizations["e"])
    scores[4] = get_vowel_score(vowel_targets["o"], [mo, mw], normalizations["o"])

    # Find the highest scoring vowel
    high = 0
    for i in range(5):
        if scores[i] > scores[high] and scores[i] > 0.2:
            high = i

    # Set vowel values
    r[vowels[high]] = scores[high]
    r[jvowels[high]] = scores[high]

    # Add blink values
    r["blink_left"] = s["eyeBlinkLeft"]
    r["ウィンク"] = s["eyeBlinkLeft"]
    r["blink_right"] = s["eyeBlinkRight"]
    r["ウィンク右"] = s["eyeBlinkRight"]

    # Convert to shapekey format
    shapekeys_result = []
    for k in r:
        shapekeys_result.append({"k": k, "v": r[k]})

    # Calculate eye rotations
    left_eye = (
        (pi/3) * (s["eyeLookDownLeft"] - s["eyeLookUpLeft"]),
        (pi/3) * (s["eyeLookOutLeft"] - s["eyeLookInLeft"]),
        0.0
    )
    right_eye = (
        (pi/3) * (s["eyeLookDownRight"] - s["eyeLookUpRight"]),
        (pi/3) * (s["eyeLookOutRight"] - s["eyeLookInRight"]),
        0.0
    )

    return (shapekeys_result, (left_eye, right_eye))