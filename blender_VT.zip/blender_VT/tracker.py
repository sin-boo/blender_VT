# Copyright (C) 2022 NueMedia Nuekaze
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import bpy, socket, json, struct
from time import sleep
from math import sin, cos, pi, radians
from .solvers import arkit_to_vowels

input_queue = {
    "Position": {"x": 0.0, "y": 0.0, "z": 0.0},
    "Rotation": {"x": 0.0, "y": 0.0, "z": 0.0},
    "BlendShapes": [],
    "Hands": {},
    "Eyes": {"x": 0.0, "y": 0.0, "z": 0.0},
    "LeftEye": (0, 0, 0),
    "RightEye": (0, 0, 0),
}

v_reset = -1

normalizations = {"a": 1.0, "i": 1.0, "u": 1.0, "e": 1.0, "o": 1.0}


def reset_vowel(v):
    global v_reset
    if v == "a":
        v_reset = 0
    elif v == "i":
        v_reset = 1
    elif v == "u":
        v_reset = 2
    elif v == "e":
        v_reset = 3
    elif v == "o":
        v_reset = 4
    elif v == "n":
        v_reset = 5


def recalculate_normalizations():
    global normalizations

    normalizations["a"] = 1 / (
        (
            (bpy.context.scene.vtt.a_open - bpy.context.scene.vtt.n_open) ** 2
            + (bpy.context.scene.vtt.a_wide - bpy.context.scene.vtt.n_wide) ** 2
        )
        ** 0.5
    )
    normalizations["i"] = 1 / (
        (
            (bpy.context.scene.vtt.i_open - bpy.context.scene.vtt.n_open) ** 2
            + (bpy.context.scene.vtt.i_wide - bpy.context.scene.vtt.n_wide) ** 2
        )
        ** 0.5
    )
    normalizations["u"] = 1 / (
        (
            (bpy.context.scene.vtt.u_open - bpy.context.scene.vtt.n_open) ** 2
            + (bpy.context.scene.vtt.u_wide - bpy.context.scene.vtt.n_wide) ** 2
        )
        ** 0.5
    )
    normalizations["e"] = 1 / (
        (
            (bpy.context.scene.vtt.e_open - bpy.context.scene.vtt.n_open) ** 2
            + (bpy.context.scene.vtt.e_wide - bpy.context.scene.vtt.n_wide) ** 2
        )
        ** 0.5
    )
    normalizations["o"] = 1 / (
        (
            (bpy.context.scene.vtt.o_open - bpy.context.scene.vtt.n_open) ** 2
            + (bpy.context.scene.vtt.o_wide - bpy.context.scene.vtt.n_wide) ** 2
        )
        ** 0.5
    )


# Copied from wikipedia.
def euler_to_quaternion(yaw, pitch, roll):
    cy = cos(radians(yaw) * 0.5)
    sy = sin(radians(yaw) * 0.5)
    cp = cos(radians(pitch) * 0.5)
    sp = sin(radians(pitch) * 0.5)
    cr = cos(radians(roll) * 0.5)
    sr = sin(radians(roll) * 0.5)

    w = cr * cp * cy + sr * sp * sy
    x = sr * cp * cy - cr * sp * sy
    y = cr * sp * cy + sr * cp * sy
    z = cr * cp * sy - sr * sp * cy

    return (w, x, y, z)


def set_rest_pose():
    bpy.context.scene.vtt.rest_px = input_queue["Position"]["x"]
    bpy.context.scene.vtt.rest_py = input_queue["Position"]["y"]
    bpy.context.scene.vtt.rest_pz = input_queue["Position"]["z"]
    bpy.context.scene.vtt.rest_rx = input_queue["Rotation"]["x"]
    bpy.context.scene.vtt.rest_ry = input_queue["Rotation"]["y"]
    bpy.context.scene.vtt.rest_rz = input_queue["Rotation"]["z"]


class Updater:
    # Save the current values for all bones and shapes before beginning.
    def __init__(self):
        self.counter = 0
        self.method = bpy.context.scene.vtt.track_method
        self.average_pointer = 0

        self.head = None
        self.root = None
        self.chest = None
        self.left_eye = None
        self.right_eye = None
        self.shapekeys = None

        # Find required bones
        try:
            self.head = bpy.context.scene.objects[
                bpy.context.scene.vtt.armature.name
            ].pose.bones[bpy.context.scene.vtt.bone_head]
            self.root = bpy.context.scene.objects[
                bpy.context.scene.vtt.armature.name
            ].pose.bones[bpy.context.scene.vtt.bone_hips]
            self.chest = bpy.context.scene.objects[
                bpy.context.scene.vtt.armature.name
            ].pose.bones[bpy.context.scene.vtt.bone_chest]
            self.left_eye = bpy.context.scene.objects[
                bpy.context.scene.vtt.armature.name
            ].pose.bones[bpy.context.scene.vtt.left_eye]
            self.right_eye = bpy.context.scene.objects[
                bpy.context.scene.vtt.armature.name
            ].pose.bones[bpy.context.scene.vtt.right_eye]
            self.shapekeys = bpy.context.scene.objects[
                bpy.context.scene.vtt.mesh.name
            ].data.shape_keys
        except KeyError:
            pass

        global input_queue
        input_queue = {
            "Position": {"x": 0.0, "y": 0.0, "z": 0.0},
            "Rotation": {"x": 0.0, "y": 0.0, "z": 0.0},
            "BlendShapes": [],
            "Hands": {},
            "Eyes": {"x": 0.0, "y": 0.0, "z": 0.0},
            "LeftEye": (0, 0, 0),
            "RightEye": (0, 0, 0),
        }

    def check(self):
        if not self.head:
            return "BONE"
        if not self.chest:
            return "BONE"
        if not self.root:
            return "BONE"
        if not self.left_eye:
            return "BONE"
        if not self.right_eye:
            return "BONE"
        if not self.shapekeys:
            return "KEY"

        return "OK"

    # Update the shapes with the recieved data
    def update(self):
        data = input_queue.copy()
        bm = bpy.context.scene.vtt.body_movement
        hbr = bpy.context.scene.vtt.head_body_ratio
        if bpy.context.scene.vtt.mirror:
            m = -1
        else:
            m = 1

        # OpenSeeFace
        if self.method == "OSF":
            quaternion = euler_to_quaternion(
                input_queue["Rotation"]["z"] - bpy.context.scene.vtt.rest_rz,
                input_queue["Rotation"]["y"] - bpy.context.scene.vtt.rest_ry,
                input_queue["Rotation"]["x"] - bpy.context.scene.vtt.rest_rx,
            )

            eyes = euler_to_quaternion(
                input_queue["Eyes"]["x"] * bpy.context.scene.vtt.eye_gaze,
                input_queue["Eyes"]["y"] * bpy.context.scene.vtt.eye_gaze * m,
                input_queue["Eyes"]["z"] * bpy.context.scene.vtt.eye_gaze,
            )
            if not bpy.context.scene.vtt.record_bones:
                self.right_eye.rotation_quaternion = eyes
                self.left_eye.rotation_quaternion = eyes

                if bpy.context.scene.vtt.record_bones:
                    self.right.keyframe_insert(
                        data_path="rotation_quaternion", group="vtuber-tracker"
                    )
                    self.left.keyframe_insert(
                        data_path="rotation_quaternion", group="vtuber-tracker"
                    )

        # Other methods
        else:
            quaternion = euler_to_quaternion(
                input_queue["Rotation"]["z"] - bpy.context.scene.vtt.rest_rz,
                input_queue["Rotation"]["x"] - bpy.context.scene.vtt.rest_rx,
                input_queue["Rotation"]["y"] - bpy.context.scene.vtt.rest_ry,
            )

        if not bpy.context.scene.vtt.disab_bones:
            h_r = (
                quaternion[0],
                quaternion[1] * (1.0 - hbr),
                quaternion[2] * (1.0 - hbr) * m,
                quaternion[3] * (1.0 - hbr),
            )

            c_r = (
                quaternion[0],
                quaternion[1] * hbr,
                quaternion[2] * hbr * m,
                quaternion[3] * hbr,
            )

            r_p = (
                (input_queue["Position"]["x"] - bpy.context.scene.vtt.rest_px)
                * 0.01
                * bpy.context.scene.vtt.body_movement
                * m
                * -1,
                (input_queue["Position"]["y"] - bpy.context.scene.vtt.rest_py)
                * 0.01
                * bpy.context.scene.vtt.body_movement,
                (input_queue["Position"]["z"] - bpy.context.scene.vtt.rest_pz)
                * 0.01
                * bpy.context.scene.vtt.body_movement,
            )

            self.root.location[0] = self.root.location[
                0
            ] * bpy.context.scene.vtt.smoothing + r_p[0] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.root.location[1] = self.root.location[
                1
            ] * bpy.context.scene.vtt.smoothing + r_p[1] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.root.location[2] = self.root.location[
                2
            ] * bpy.context.scene.vtt.smoothing + r_p[2] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )

            self.head.rotation_quaternion[0] = self.head.rotation_quaternion[
                0
            ] * bpy.context.scene.vtt.smoothing + h_r[0] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.head.rotation_quaternion[1] = self.head.rotation_quaternion[
                1
            ] * bpy.context.scene.vtt.smoothing + h_r[1] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.head.rotation_quaternion[2] = self.head.rotation_quaternion[
                2
            ] * bpy.context.scene.vtt.smoothing + h_r[2] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.head.rotation_quaternion[3] = self.head.rotation_quaternion[
                3
            ] * bpy.context.scene.vtt.smoothing + h_r[3] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )

            self.chest.rotation_quaternion[0] = self.chest.rotation_quaternion[
                0
            ] * bpy.context.scene.vtt.smoothing + c_r[0] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.chest.rotation_quaternion[1] = self.chest.rotation_quaternion[
                1
            ] * bpy.context.scene.vtt.smoothing + c_r[1] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.chest.rotation_quaternion[2] = self.chest.rotation_quaternion[
                2
            ] * bpy.context.scene.vtt.smoothing + c_r[2] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )
            self.chest.rotation_quaternion[3] = self.chest.rotation_quaternion[
                3
            ] * bpy.context.scene.vtt.smoothing + c_r[3] * (
                1.0 - bpy.context.scene.vtt.smoothing
            )

            if bpy.context.scene.vtt.use_vowels:
                # If eyes are from vowel conversion
                l_eye_q = euler_to_quaternion(
                    input_queue["LeftEye"][2] * bpy.context.scene.vtt.eye_gaze * 10,
                    input_queue["LeftEye"][1] * bpy.context.scene.vtt.eye_gaze * 10 * m,
                    input_queue["LeftEye"][0] * bpy.context.scene.vtt.eye_gaze * 10,
                )
                r_eye_q = euler_to_quaternion(
                    input_queue["RightEye"][2] * bpy.context.scene.vtt.eye_gaze * 10,
                    -input_queue["RightEye"][1] * bpy.context.scene.vtt.eye_gaze * 10 * m,
                    input_queue["RightEye"][0] * bpy.context.scene.vtt.eye_gaze * 10,
                )

                self.left_eye.rotation_quaternion[0] = self.left_eye.rotation_quaternion[
                    0
                ] * bpy.context.scene.vtt.smoothing + l_eye_q[0] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )
                self.left_eye.rotation_quaternion[1] = self.left_eye.rotation_quaternion[
                    1
                ] * bpy.context.scene.vtt.smoothing + l_eye_q[1] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )
                self.left_eye.rotation_quaternion[2] = self.left_eye.rotation_quaternion[
                    2
                ] * bpy.context.scene.vtt.smoothing + l_eye_q[2] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )
                self.left_eye.rotation_quaternion[3] = self.left_eye.rotation_quaternion[
                    3
                ] * bpy.context.scene.vtt.smoothing + l_eye_q[3] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )

                self.right_eye.rotation_quaternion[0] = self.right_eye.rotation_quaternion[
                    0
                ] * bpy.context.scene.vtt.smoothing + r_eye_q[0] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )
                self.right_eye.rotation_quaternion[1] = self.right_eye.rotation_quaternion[
                    1
                ] * bpy.context.scene.vtt.smoothing + r_eye_q[1] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )
                self.right_eye.rotation_quaternion[2] = self.right_eye.rotation_quaternion[
                    2
                ] * bpy.context.scene.vtt.smoothing + r_eye_q[2] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )
                self.right_eye.rotation_quaternion[3] = self.right_eye.rotation_quaternion[
                    3
                ] * bpy.context.scene.vtt.smoothing + r_eye_q[3] * (
                    1.0 - bpy.context.scene.vtt.smoothing
                )

            if bpy.context.scene.vtt.record_bones:
                self.head.keyframe_insert(
                    data_path="rotation_quaternion", group="vtuber-tracker"
                )
                self.chest.keyframe_insert(
                    data_path="rotation_quaternion", group="vtuber-tracker"
                )
                self.root.keyframe_insert(data_path="location", group="vtuber-tracker")

        # Update blendshapes
        if not bpy.context.scene.vtt.disab_shapekeys:
            for s in input_queue["BlendShapes"]:
                try:
                    self.shapekeys.key_blocks[s["k"]].value = self.shapekeys.key_blocks[
                        s["k"]
                    ].value * bpy.context.scene.vtt.smoothing + s["v"] * (
                        1.0 - bpy.context.scene.vtt.smoothing
                    )
                    if bpy.context.scene.vtt.record_shapekeys:
                        self.shapekeys.key_blocks[s["k"]].keyframe_insert(
                            data_path="value", group="vtuber-tracker"
                        )
                except KeyError:
                    pass

    def reset(self):
        # Reset everything
        self.head.rotation_quaternion = (1, 0, 0, 0)
        self.chest.rotation_quaternion = (1, 0, 0, 0)
        self.left_eye.rotation_quaternion = (1, 0, 0, 0)
        self.right_eye.rotation_quaternion = (1, 0, 0, 0)
        self.root.location = (0, 0, 0)

        for s in bpy.context.scene.objects[
            bpy.context.scene.vtt.mesh.name
        ].data.shape_keys.key_blocks:
            s.value = 0


class Poller:
    def __init__(self, ip, port):
        self.run = 1
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ip = ip
        self.port = port

    def start(self):
        while self.run:
            if bpy.context.scene.vtt.track_method == "VTS":
                self.sock.sendto(
                    bytes(
                        json.dumps(
                            {
                                "messageType": "iOSTrackingDataRequest",
                                "sentBy": "Blender",
                                "sendForSeconds": 5,
                                "ports": [self.port],
                            }
                        ),
                        "utf-8",
                    ),
                    (self.ip, 21412),
                )

            elif bpy.context.scene.vtt.track_method == "IFM":
                self.sock.sendto(
                    bytes(
                        "iFacialMocap_sahuasouryya9218sauhuiayeta91555dy3719", "utf-8"
                    ),
                    (self.ip, 49983),
                )

            else:
                return

            sleep(1)


def get_score(target, sample, v):
    rx = (sample[0] - target[0]) ** 2
    ry = (sample[1] - target[1]) ** 2

    return 1 - ((rx + ry) ** 0.5) * normalizations[v]


class Listener:
    def __init__(self, port):
        self.run = 1
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", self.port))
        if bpy.context.scene.vtt.track_method == "OSF":
            recalculate_normalizations()

    def start(self):
        global input_queue
        global v_reset
        while self.run:
            data, addr = self.sock.recvfrom(4096)

            if bpy.context.scene.vtt.track_method == "OSF":
                c = 20
                rightEye = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                leftEye = struct.unpack("f", data[c : c + 4])[0]
                c += 9

                quaternion = (
                    struct.unpack("f", data[c + 4 : c + 8])[0],
                    struct.unpack("f", data[c + 8 : c + 12])[0],
                    struct.unpack("f", data[c + 12 : c + 16])[0],
                    struct.unpack("f", data[c : c + 4])[0],
                )
                c += 16

                euler = (
                    struct.unpack("f", data[c : c + 4])[0],
                    struct.unpack("f", data[c + 4 : c + 8])[0],
                    struct.unpack("f", data[c + 8 : c + 12])[0],
                )
                c += 12

                tx = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                ty = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                tz = struct.unpack("f", data[c : c + 4])[0]

                c += 4 + 4 * 68 + 4 * 2 * 68

                # This part may memoryleak but it should be fine. List.append is not very good.
                points3D = []
                for i in range(70):
                    points3D.append(
                        [
                            struct.unpack("f", data[c : c + 4])[0],
                            struct.unpack("f", data[c + 4 : c + 8])[0],
                            struct.unpack("f", data[c + 8 : c + 12])[0],
                        ]
                    )
                    c += 12

                shapes = {}
                shapes["EyeLeft"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyeRight"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyebrowSteepnessLeft"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyebrowUpDownLeft"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyebrowQuirkLeft"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyebrowSteepnessRight"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyebrowUpDownRight"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["EyebrowQuirkRight"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["MouthCornerUpDownLeft"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["MouthCornerInOutLeft"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["MouthCornerUpDownRight"] = struct.unpack("f", data[c : c + 4])[
                    0
                ]
                c += 4
                shapes["MouthCornerInOutRight"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["MouthOpen"] = struct.unpack("f", data[c : c + 4])[0]
                c += 4
                shapes["MouthWide"] = struct.unpack("f", data[c : c + 4])[0]

                # If we should recalibrate the vowels.
                if v_reset != -1:
                    if v_reset == 0:
                        bpy.context.scene.vtt.a_open = shapes["MouthOpen"]
                        bpy.context.scene.vtt.a_wide = shapes["MouthWide"]
                    elif v_reset == 1:
                        bpy.context.scene.vtt.i_open = shapes["MouthOpen"]
                        bpy.context.scene.vtt.i_wide = shapes["MouthWide"]
                    elif v_reset == 2:
                        bpy.context.scene.vtt.u_open = shapes["MouthOpen"]
                        bpy.context.scene.vtt.u_wide = shapes["MouthWide"]
                    elif v_reset == 3:
                        bpy.context.scene.vtt.e_open = shapes["MouthOpen"]
                        bpy.context.scene.vtt.e_wide = shapes["MouthWide"]
                    elif v_reset == 4:
                        bpy.context.scene.vtt.o_open = shapes["MouthOpen"]
                        bpy.context.scene.vtt.o_wide = shapes["MouthWide"]
                    elif v_reset == 5:
                        bpy.context.scene.vtt.n_open = shapes["MouthOpen"]
                        bpy.context.scene.vtt.n_wide = shapes["MouthWide"]
                    v_reset = -1
                    recalculate_normalizations()

                input_queue["BlendShapes"] = [
                    {"k": "a", "v": 0.0},
                    {"k": "i", "v": 0.0},
                    {"k": "u", "v": 0.0},
                    {"k": "e", "v": 0.0},
                    {"k": "o", "v": 0.0},
                    {"k": "blink_right", "v": 0.0},
                    {"k": "blink_left", "v": 0.0},
                ]

                vowels = ["a", "i", "u", "e", "o"]

                # Calculate all vowels
                scores = [0, 0, 0, 0, 0]
                scores[0] = get_score(
                    (bpy.context.scene.vtt.a_open, bpy.context.scene.vtt.a_wide),
                    (shapes["MouthOpen"], shapes["MouthWide"]),
                    "a",
                )
                scores[1] = get_score(
                    (bpy.context.scene.vtt.i_open, bpy.context.scene.vtt.i_wide),
                    (shapes["MouthOpen"], shapes["MouthWide"]),
                    "i",
                )
                scores[2] = get_score(
                    (bpy.context.scene.vtt.u_open, bpy.context.scene.vtt.u_wide),
                    (shapes["MouthOpen"], shapes["MouthWide"]),
                    "u",
                )
                scores[3] = get_score(
                    (bpy.context.scene.vtt.e_open, bpy.context.scene.vtt.e_wide),
                    (shapes["MouthOpen"], shapes["MouthWide"]),
                    "e",
                )
                scores[4] = get_score(
                    (bpy.context.scene.vtt.o_open, bpy.context.scene.vtt.o_wide),
                    (shapes["MouthOpen"], shapes["MouthWide"]),
                    "o",
                )

                # Get highest value
                h = 0
                for i in range(5):
                    if scores[i] > scores[h]:
                        h = i

                input_queue["BlendShapes"][h]["v"] = scores[h]
                input_queue["BlendShapes"][5]["v"] = shapes["EyeRight"] * -1
                input_queue["BlendShapes"][6]["v"] = shapes["EyeLeft"] * -1

                # Calculate rotation
                input_queue["Rotation"] = {
                    "x": ((euler[0] + 180) * -1 % 360) * pi / 180,
                    "y": euler[1] * pi / 180,
                    "z": (euler[2] - 90 % 360) * pi / 180,
                }

                if input_queue["Rotation"]["x"] > pi:
                    input_queue["Rotation"]["x"] -= pi * 2

                input_queue["Position"]["x"] = ty / -20
                input_queue["Position"]["z"] = tz / 20
                input_queue["Position"]["y"] = tx / 20

                input_queue["Rotation"]["x"] = input_queue["Rotation"]["x"] * -1
                input_queue["Rotation"]["y"] = input_queue["Rotation"]["y"] * -1
                input_queue["Rotation"]["z"] = input_queue["Rotation"]["z"] * -1

                input_queue["Eyes"]["y"] = points3D[66][0] - points3D[68][0]
                input_queue["Eyes"]["z"] = points3D[66][1] - points3D[68][1]
                input_queue["Eyes"]["x"] = 0.0

            # We use iFacialMocap
            elif bpy.context.scene.vtt.track_method == "IFM":
                data = data.decode("utf-8")
                data = data.split("|")
                
                queue = {"Position": {}, "Rotation": {}, "BlendShapes": []}
                
                # Process all blend shapes
                for i in range(len(data)-1):
                    if "-" in data[i+1]:
                        # Split only on the first hyphen to handle cases with multiple hyphens
                        parts = data[i+1].split("-", 1)
                        if len(parts) == 2:
                            key, val = parts
                            key = key.replace("_R", "Right").replace("_L", "Left")
                            try:
                                val = float(val) / 100.0
                                queue["BlendShapes"].append({"k": key, "v": val})
                            except ValueError:
                                # Skip if value can't be converted to float
                                continue
                
                # Process position and rotation data
                if len(data) > 54 and "#" in data[54]:
                    pos_rots = data[54].split("#")[1].split(",")
                    if len(pos_rots) >= 6:
                        try:
                            queue["Position"]["x"] = float(pos_rots[3]) * -100
                            queue["Position"]["y"] = float(pos_rots[4]) * 100
                            queue["Position"]["z"] = float(pos_rots[5]) * 100
                            
                            queue["Rotation"]["y"] = float(pos_rots[0])
                            queue["Rotation"]["x"] = float(pos_rots[1])
                            queue["Rotation"]["z"] = float(pos_rots[2])
                        except (ValueError, IndexError):
                            # Use default values if conversion fails
                            queue["Position"]["x"] = 0.0
                            queue["Position"]["y"] = 0.0
                            queue["Position"]["z"] = 0.0
                            queue["Rotation"]["y"] = 0.0
                            queue["Rotation"]["x"] = 0.0
                            queue["Rotation"]["z"] = 0.0
                
                if bpy.context.scene.vtt.use_vowels:
                    vowels, eyes = arkit_to_vowels(queue["BlendShapes"])
                    queue["BlendShapes"] = vowels
                    queue["LeftEye"] = eyes[0]
                    queue["RightEye"] = eyes[1]
                
                input_queue = queue

            # We use VTube Studio or MeowFace
            else:
                try:
                    data = json.loads(data)

                    if data["FaceFound"]:
                        for b in data["BlendShapes"]:
                            b["k"] = b["k"][0].lower() + b["k"][1:]
                        if bpy.context.scene.vtt.use_vowels:
                            vowels, eyes = arkit_to_vowels(data["BlendShapes"])
                            data["BlendShapes"] = vowels
                            data["LeftEye"] = [
                                radians(data["EyeLeft"]["x"]),
                                radians(data["EyeLeft"]["y"]),
                                0.0
                            ]
                            data["RightEye"] = [
                                radians(data["EyeRight"]["x"]),
                                -radians(data["EyeRight"]["y"]),
                                0.0
                            ]

                        input_queue = data

                except json.decoder.JSONDecodeError:
                    pass

    def stop(self):
        self.run = 0
        self.sock.sendto(
            bytes('{"FaceFound":false}', "utf-8"), ("127.0.0.1", self.port)
        )