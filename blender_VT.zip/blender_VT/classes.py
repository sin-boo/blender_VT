﻿# Copyright (C) 2022 NueMedia Nuekaze
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from bpy.types import PropertyGroup, Operator, Panel, Object
from bpy.props import (
    IntProperty,
    FloatProperty,
    StringProperty,
    PointerProperty,
    EnumProperty,
    BoolProperty,
)
from threading import Thread
from socket import inet_aton
from .tracker import Poller, Listener, Updater, reset_vowel, set_rest_pose


# Get a list of all bones.
def get_bones(self, context):
    bones = []
    try:
        for o in context.scene.objects[context.scene.vtt.armature.name].pose.bones:
            bones.append((o.name, o.name, o.name))
    except KeyError:
        return []
    return bones


# Get a list of all armatures.
def get_armatures(self, context):
    armatures = []
    for o in context.scene.objects:
        if o.type == "ARMATURE":
            armatures.append((o.name, o.name, o.name))
    return armatures


# Get a list of all meshes.
def get_meshes(self, context):
    meshes = []
    for o in context.scene.objects:
        if o.type == "MESH":
            meshes.append((o.name, o.name, o.name))
    return meshes


# Tracking types
t_types = (
    ("OSF", "OpenSeeFace", "Track using OpenSeeFace."),
    ("IFM", "iFacialMocap", "Track using iFacialMocap."),
    ("VTS", "VTube Studio/MeowFace", "Track using VTube Stuio or MeowFace."),
)

vowels = (
    ("n", "Neutral", "Neutral face"),
    ("a", "A", "A vowel"),
    ("i", "I", "I vowel"),
    ("u", "U", "U vowel"),
    ("e", "E", "E vowel"),
    ("o", "O", "O vowel"),
)


class VTTSettings(PropertyGroup):
    armature: PointerProperty(
        name="Armature", type=Object, description="Armature to track"
    )
    bone_head: StringProperty(
        name="Head", default="Head", description="The bone that moves the head"
    )
    bone_chest: StringProperty(
        name="Chest", default="Chest", description="The bone that moves the chest"
    )
    bone_hips: StringProperty(
        name="Hips", default="Hips", description="The bone that moves the hips"
    )
    left_eye: StringProperty(
        name="Left eye",
        default="LeftEye",
        description="The bone that moves the left eye",
    )
    right_eye: StringProperty(
        name="Right eye",
        default="RightEye",
        description="The bone that moves the right eye",
    )
    mesh: PointerProperty(
        name="Facemesh",
        type=Object,
        description="The mesh for the face that contains shapekeys",
    )
    track_method: EnumProperty(
        name="Tracking", items=t_types, description="Tracking method to use"
    )
    phone_ip: StringProperty(
        name="Phone IP", default="192.168.1.", description="IP address of phone"
    )
    vts_port: IntProperty(
        name="Listening port",
        default=50506,
        description="Listening port for tracker data",
    )
    ifm_port: IntProperty(
        name="Listening port",
        default=49983,
        description="Listening port for tracker data",
    )
    osf_port: IntProperty(
        name="Listening port",
        default=11573,
        description="Listening port for tracker data",
    )
    smoothing: FloatProperty(
        name="Smoothing",
        default=0.2,
        soft_min=0.0,
        soft_max=1.0,
        description="Smoothen body tracking",
    )
    body_movement: FloatProperty(
        name="Body movement",
        default=1.0,
        soft_min=0.0,
        description="Amount of body movement",
    )
    head_body_ratio: FloatProperty(
        name="Head to body movement ratio",
        default=0.3,
        soft_min=0.0,
        soft_max=1.0,
        description="Ration between body movement and head movement",
    )
    eye_gaze: FloatProperty(
        name="Eye gaze strength",
        default=5.0,
        soft_min=0.0,
        description="Eye gaze strength",
    )
    framerate: IntProperty(
        name="Framerate",
        default=24,
        soft_min=1,
        soft_max=120,
        description="The rate that the mesh should be updated",
    )
    mirror: BoolProperty(
        name="Mirror movement",
        default=False,
        description="Mirror the movement and gaze",
    )
    res_vowel: EnumProperty(
        name="Vowel", default=0, items=vowels, description="Vowel to calibrate"
    )
    record_shapekeys: BoolProperty(
        name="Record shapekeys", default=False, description="Enable shapekey recording"
    )
    record_bones: BoolProperty(
        name="Record bones", default=False, description="Enable bones recording"
    )
    disab_shapekeys: BoolProperty(
        name="Disable shapekeys",
        default=False,
        description="Prevent new tracking data towards shapekeys to be applied",
    )
    disab_bones: BoolProperty(
        name="Disable bones",
        default=False,
        description="Prevent new tracking data towards bones to be applied",
    )

    use_vowels: BoolProperty(
        name="Use vowels",
        default=False,
        description="Use the ARKit to vowel solver if ARKit shapekeys are not available."
    )

    # Looks ugly but works. Used for reset pose.
    rest_rx: FloatProperty()
    rest_ry: FloatProperty()
    rest_rz: FloatProperty()
    rest_px: FloatProperty()
    rest_py: FloatProperty()
    rest_pz: FloatProperty()

    # I really need to learn how to make array properties. But it works for now.
    n_open: FloatProperty(default=-0.5)
    n_wide: FloatProperty(default=-0.5)
    a_open: FloatProperty(default=0.6)
    a_wide: FloatProperty(default=0.3)
    i_open: FloatProperty(default=0.2)
    i_wide: FloatProperty(default=0.7)
    u_open: FloatProperty(default=0.0)
    u_wide: FloatProperty(default=-0.4)
    e_open: FloatProperty(default=0.3)
    e_wide: FloatProperty(default=0.4)
    o_open: FloatProperty(default=0.3)
    o_wide: FloatProperty(default=-0.4)


# Threads and objects
t_poller = None
t_listener = None
o_poller = None
o_listener = None
state = 0


class ANIM_OT_vtt_start(Operator):
    bl_idname = "vtt.start"
    bl_label = "🎬 Start VTube Tracking"
    bl_description = "Start face tracking for VTube applications"
    timer = None
    updater = None

    @classmethod
    def poll(cls, context):
        if not context.scene.vtt.armature:
            return False
        if not context.scene.vtt.bone_head:
            return False
        if not context.scene.vtt.bone_chest:
            return False
        if not context.scene.vtt.bone_hips:
            return False
        if not context.scene.vtt.mesh:
            return False
        if not context.scene.vtt.left_eye:
            return False
        if not context.scene.vtt.right_eye:
            return False
        return True

    # Update mesh on frame tick
    def modal(self, context, event):
        # Pass through all other events.
        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        if t_listener == None:
            context.window_manager.event_timer_remove(self.timer)
            self.updater.reset()
            return {"FINISHED"}

        self.updater.update()

        return {"RUNNING_MODAL"}

    # Initialize and start poller and listener
    def invoke(self, context, event):
        global o_poller
        global o_listener
        global t_poller
        global t_listener
        global state

        if context.scene.vtt.track_method == "VTS":
            try:
                inet_aton(context.scene.vtt.phone_ip)
            except:
                self.report({"ERROR"}, "Not a valid IP address.")
                return {"CANCELLED"}

            port = context.scene.vtt.vts_port

        elif context.scene.vtt.track_method == "IFM":
            try:
                inet_aton(context.scene.vtt.phone_ip)
            except:
                self.report({"ERROR"}, "Not a valid IP address.")
                return {"CANCELLED"}

            port = context.scene.vtt.ifm_port

        else:
            port = context.scene.vtt.osf_port

        self.updater = Updater()

        # In case we failed to init.
        code = self.updater.check()
        if code == "BONE":
            self.report({"ERROR"}, "One or more bones does not exist or bones are not named corecly pleas select moddel_modifier if this does not fix it youl need to do it manually.")
            return {"CANCELLED"}

        if code == "KEY":
            self.report({"ERROR"}, "The facemesh does not have any shapekeys.")
            return {"CANCELLED"}

        o_poller = Poller(context.scene.vtt.phone_ip, port)
        t_poller = Thread(target=o_poller.start, daemon=True)
        t_poller.start()

        o_listener = Listener(port)
        t_listener = Thread(target=o_listener.start, daemon=True)
        t_listener.start()

        state = 1

        context.window_manager.modal_handler_add(self)
        self.timer = context.window_manager.event_timer_add(
            1 / context.scene.vtt.framerate, window=context.window
        )

        return {"RUNNING_MODAL"}

    def execute(self, context):
        return self.invoke(context, None)


class ANIM_OT_vtt_stop(Operator):
    bl_idname = "vtt.stop"
    bl_label = "⏹️ Stop VTube Tracking"
    bl_description = "Stop face tracking"

    @classmethod
    def poll(cls, context):
        if o_poller:
            return True
        if o_listener:
            return True
        if t_poller:
            return True
        if t_listener:
            return True

        return False

    def execute(self, context):
        global o_poller
        global o_listener
        global t_poller
        global t_listener
        global state

        if o_listener:
            if o_listener.run:
                o_listener.stop()

        if o_poller:
            if o_poller.run:
                o_poller.run = 0

        if t_listener:
            if t_listener.is_alive():
                t_listener.join()

        if t_poller:
            if t_poller.is_alive():
                t_poller.join()

        del o_listener
        del o_poller
        del t_listener
        del t_poller

        t_poller = None
        t_listener = None
        o_poller = None
        o_listener = None

        state = 0

        return {"FINISHED"}


class ANIM_OT_vtt_reset_vowel(Operator):
    bl_idname = "vtt.reset_vowel"
    bl_label = "🎵 Calibrate Vowel"
    bl_description = "Set current face values to target vowel"

    @classmethod
    def poll(cls, context):
        if context.scene.vtt.track_method == "OSF" and state:
            return True
        return False

    def execute(self, context):
        reset_vowel(context.scene.vtt.res_vowel[0])

        return {"FINISHED"}


class ANIM_OT_vtt_reset_rest(Operator):
    bl_idname = "vtt.reset_rest"
    bl_label = "🔄 Reset Rest Pose"
    bl_description = "Reset the resting pose for tracking"

    @classmethod
    def poll(cls, context):
        if state:
            return True
        return False

    def execute(self, context):
        set_rest_pose()

        return {"FINISHED"}


class ANIM_PT_vtt(Panel):
    bl_label = "🎭 VTube Face Tracker"
    bl_category = "blender_VT"
    bl_idname = "ANIM_PT_vtt"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_order = 1

    def draw(self, context):
        global state
        layout = self.layout

        # Header with status indicator
        header_box = layout.box()
        header_row = header_box.row()
        header_row.label(text="VTube Face Tracking", icon='CAMERA_DATA')
        
        status_row = header_box.row()
        if state:
            status_row.label(text="Status: Active", icon='PLAY')
        else:
            status_row.label(text="Status: Ready", icon='PAUSE')
        
        # Control buttons
        control_box = layout.box()
        control_row = control_box.row(align=True)
        if state:
            control_row.operator("vtt.stop", text="Stop Tracking", icon='PAUSE')
        else:
            control_row.operator("vtt.start", text="Start Tracking", icon='PLAY')

        # Model setup section
        model_box = layout.box()
        model_box.label(text="🧬 Model Setup", icon='OUTLINER_OB_ARMATURE')
        model_box.prop(context.scene.vtt, "armature")
        
        if context.scene.vtt.armature:
            bones_col = model_box.column(align=True)
            bones_col.prop_search(context.scene.vtt, "bone_head", context.scene.objects[context.scene.vtt.armature.name].pose, "bones", text="Head")
            bones_col.prop_search(context.scene.vtt, "bone_chest", context.scene.objects[context.scene.vtt.armature.name].pose, "bones", text="Chest")
            bones_col.prop_search(context.scene.vtt, "bone_hips", context.scene.objects[context.scene.vtt.armature.name].pose, "bones", text="Hips")
            
            eyes_row = bones_col.split(factor=0.5, align=True)
            eyes_row.prop_search(context.scene.vtt, "left_eye", context.scene.objects[context.scene.vtt.armature.name].pose, "bones", text="Left Eye")
            eyes_row.prop_search(context.scene.vtt, "right_eye", context.scene.objects[context.scene.vtt.armature.name].pose, "bones", text="Right Eye")
            
            model_box.prop(context.scene.vtt, "mesh", text="Face Mesh")

        # Tracking settings section
        track_box = layout.box()
        track_box.label(text="📡 Tracking Settings", icon='TRACKING')
        track_box.prop(context.scene.vtt, "track_method")
        
        if context.scene.vtt.track_method == "OSF":
            track_box.prop(context.scene.vtt, "osf_port", text="Port")
        elif context.scene.vtt.track_method == "VTS":
            track_box.prop(context.scene.vtt, "phone_ip", text="Phone IP")
            track_box.prop(context.scene.vtt, "vts_port", text="Port")
        else:
            track_box.prop(context.scene.vtt, "phone_ip", text="Phone IP")
            track_box.prop(context.scene.vtt, "ifm_port", text="Port")

        # Tracking adjustments section
        adjust_box = layout.box()
        adjust_box.label(text="⚙️ Tracking Adjustments", icon='SETTINGS')
        
        # First row of adjustments
        adjust_row1 = adjust_box.split(factor=0.5, align=True)
        adjust_row1.prop(context.scene.vtt, "framerate", text="Framerate")
        adjust_row1.prop(context.scene.vtt, "smoothing", text="Smoothing")
        
        # Second row of adjustments
        adjust_row2 = adjust_box.split(factor=0.5, align=True)
        adjust_row2.prop(context.scene.vtt, "head_body_ratio", text="Head/Body Ratio")
        adjust_row2.prop(context.scene.vtt, "body_movement", text="Body Movement")
        
        # Third row of adjustments
        adjust_row3 = adjust_box.split(factor=0.5, align=True)
        adjust_row3.prop(context.scene.vtt, "eye_gaze", text="Eye Gaze")
        adjust_row3.prop(context.scene.vtt, "mirror", text="Mirror")
        
        if context.scene.vtt.track_method != "OSF":
            adjust_box.prop(context.scene.vtt, "use_vowels", text="Use Vowels")

        # Calibration section
        calib_box = layout.box()
        calib_box.label(text="🎯 Calibration", icon='TOOL_SETTINGS')
        
        if context.scene.vtt.track_method == "OSF":
            calib_row = calib_box.split(factor=0.7, align=True)
            calib_row.prop(context.scene.vtt, "res_vowel", text="")
            calib_row.operator("vtt.reset_vowel", text="Calibrate")
        
        calib_box.operator("vtt.reset_rest", text="Reset Rest Pose", icon='ARMATURE_DATA')
        
        # Footer with version info
        footer = layout.row()
        footer.alignment = 'CENTER'
        footer.label(text="VTube Tracker v1.3.0")