# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "blender_VT",
    "author" : "sin_Gib", 
    "description" : "blender_VT is a addon designed for VTubers who want to break free from the limitations of standard VTuber software",
    "blender" : (4, 5, 2),
    "version" : (0, 1, 5),
    "location" : "View3D > Sidebar > blender_VT",
    "warning" : "",
    "doc_url": "https://github.com/sin-boo/blender_VT", 
    "tracker_url": "https://github.com/sin-boo/blender_VT/issues", 
    "category" : "Legacy User"
}

import bpy
import bpy.utils.previews
import os
from .classes import VTTSettings, ANIM_PT_vtt, ANIM_OT_vtt_start, ANIM_OT_vtt_stop, ANIM_OT_vtt_reset_vowel, ANIM_OT_vtt_reset_rest

addon_keymaps = {}
_icons = None

class SNA_OT_Window_Open_F3Bce(bpy.types.Operator):
    bl_idname = "sna.window_open_f3bce"
    bl_label = "New Viewport Window"
    bl_description = "Create a new window with a 3D Viewport"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.wm.window_new()
        new_window = bpy.context.window_manager.windows[-1]
        area = new_window.screen.areas[0]
        area.type = 'VIEW_3D'
        return {"FINISHED"}

class SNA_OT_Off_F6Fbf(bpy.types.Operator):
    bl_idname = "sna.off_f6fbf"
    bl_label = "Hide UI"
    bl_description = "Turn off gizmos and overlays"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        area = bpy.context.area
        if area and area.type == 'VIEW_3D':
            space = area.spaces[0]
            space.overlay.show_overlays = False
            space.show_gizmo = False
        return {"FINISHED"}

class SNA_OT_On_F7884(bpy.types.Operator):
    bl_idname = "sna.on_f7884"
    bl_label = "Show UI"
    bl_description = "Turn on gizmos and overlays"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                space = area.spaces[0]
                space.overlay.show_overlays = True
                space.show_gizmo = True
        return {"FINISHED"}

class SNA_OT_Basic_Set_Up_5C085(bpy.types.Operator):
    bl_idname = "sna.basic_set_up_5c085"
    bl_label = "Import Camera Setup"
    bl_description = "Import camera collection from assets/camra_setup.blend"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        addon_dir = os.path.dirname(__file__)
        assets_dir = os.path.join(addon_dir, "assets")
        blend_path = os.path.join(assets_dir, "camra_setup.blend")
        
        if not os.path.exists(blend_path):
            self.report({'ERROR'}, "assets/camra_setup.blend file not found in addon directory")
            return {"CANCELLED"}
            
        before_data = list(bpy.data.collections)
        bpy.ops.wm.append(directory=blend_path + r'\Collection', filename='Camera', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.collections)))
        return {"FINISHED"}

class SNA_OT_Camra_62Ea3(bpy.types.Operator):
    bl_idname = "sna.camra_62ea3"
    bl_label = "Switch to Camera View"
    bl_description = "Switch to camera view in 3D viewport"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.view3d.view_camera('INVOKE_DEFAULT')
        bpy.context.area.type = prev_context
        return {"FINISHED"}

class SNA_OT_Moddel_Modifier_Bones_21C98(bpy.types.Operator):
    bl_idname = "sna.moddel_modifier_bones_21c98"
    bl_label = "Standardize Bone Names"
    bl_description = "Warning: This will change your model's bone names"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        def rename_bones():
            name_mapping = {
                "J_Bip_C_Head": "Head",
                "J_Bip_C_UpperChest": "Chest", 
                "J_Bip_C_Hips": "Hips",
                "J_Adj_L_FaceEye": "LeftEye",
                "J_Adj_R_FaceEye": "RightEye"
            }
            
            armature = bpy.context.active_object
            if not armature or armature.type != 'ARMATURE':
                self.report({'ERROR'}, "No active armature selected")
                return False
                
            current_mode = bpy.context.object.mode
            bpy.ops.object.mode_set(mode='EDIT')
            
            renamed_count = 0
            for old_name, new_name in name_mapping.items():
                bone = armature.data.edit_bones.get(old_name)
                if bone:
                    bone.name = new_name
                    renamed_count += 1
                    
            bpy.ops.object.mode_set(mode=current_mode)
            self.report({'INFO'}, f"Renamed {renamed_count} bones")
            return True
            
        rename_bones()
        return {"FINISHED"}

class SNA_OT_Blend_Shapes_8Eb80(bpy.types.Operator):
    bl_idname = "sna.blend_shapes_8eb80"
    bl_label = "Standardize Shape Key Names"
    bl_description = "Warning: This will change your model's shape key names"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        import difflib
        
        TARGET_SHAPE_KEYS = [
            "browInnerUp", "browDownLeft", "browDownRight", "browOuterUpLeft", "browOuterUpRight",
            "eyeLookUpLeft", "eyeLookUpRight", "eyeLookDownLeft", "eyeLookDownRight",
            "eyeLookInLeft", "eyeLookInRight", "eyeLookOutLeft", "eyeLookOutRight",
            "eyeBlinkLeft", "eyeBlinkRight", "eyeSquintRight", "eyeSquintLeft",
            "eyeWideLeft", "eyeWideRight", "cheekPuff", "cheekSquintLeft", "cheekSquintRight",
            "noseSneerLeft", "noseSneerRight", "jawOpen", "jawForward", "jawLeft", "jawRight",
            "mouthFunnel", "mouthPucker", "mouthLeft", "mouthRight", "mouthRollUpper",
            "mouthRollLower", "mouthShrugUpper", "mouthShrugLower", "mouthClose",
            "mouthSmileLeft", "mouthSmileRight", "mouthFrownLeft", "mouthFrownRight",
            "mouthDimpleLeft", "mouthDimpleRight", "mouthUpperUpLeft", "mouthUpperUpRight",
            "mouthLowerDownLeft", "mouthLowerDownRight", "mouthPressLeft", "mouthPressRight",
            "mouthStretchLeft", "mouthStretchRight"
        ]
        
        EXACT_MAPPINGS = {
            "Fcl_MTH_A": "a",
            "Fcl_MTH_I": "i",
            "Fcl_MTH_U": "u",
            "Fcl_MTH_E": "e",
            "Fcl_MTH_O": "o"
        }

        def rename_shape_keys():
            selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            if not selected_objects:
                self.report({'ERROR'}, "No mesh objects selected")
                return
                
            for obj in selected_objects:
                if not obj.data.shape_keys:
                    continue
                    
                key_blocks = obj.data.shape_keys.key_blocks
                renamed_count = 0
                
                for key in key_blocks:
                    if key.name in EXACT_MAPPINGS:
                        new_name = EXACT_MAPPINGS[key.name]
                        key.name = new_name
                        renamed_count += 1
                        continue
                        
                    matches = difflib.get_close_matches(key.name, TARGET_SHAPE_KEYS, n=1, cutoff=0.9)
                    if matches:
                        best_match = matches[0]
                        similarity = difflib.SequenceMatcher(None, key.name, best_match).ratio()
                        if similarity >= 0.9:
                            key.name = best_match
                            renamed_count += 1
                
                self.report({'INFO'}, f"Renamed {renamed_count} shape keys on {obj.name}")
                
        rename_shape_keys()
        return {"FINISHED"}

class SNA_PT_BLENDER_VT_17B29(bpy.types.Panel):
    bl_label = 'Viewport Tools'
    bl_idname = 'SNA_PT_BLENDER_VT_17B29'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'blender_VT'
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        
        # Viewport controls
        box = layout.box()
        row = box.row(align=True)
        row.operator("sna.window_open_f3bce", text="New Viewport", icon='WINDOW')
        row = box.row(align=True)
        row.operator("sna.off_f6fbf", text="Hide UI", icon='HIDE_ON')
        row.operator("sna.on_f7884", text="Show UI", icon='HIDE_OFF')
        
        # Camera controls
        box = layout.box()
        row = box.row(align=True)
        row.operator("sna.basic_set_up_5c085", text="Import Camera", icon='CAMERA_DATA')
        row.operator("sna.camra_62ea3", text="View Camera", icon='VIEW_CAMERA')
        
        # Model tools
        box = layout.box()
        row = box.row(align=True)
        row.operator("sna.moddel_modifier_bones_21c98", text="Fix Bones", icon='BONE_DATA')
        row.operator("sna.blend_shapes_8eb80", text="Fix Shape Keys", icon='SHAPEKEY_DATA')

def register():
    global _icons
    _icons = bpy.utils.previews.new()
    
    # Register first addon classes
    bpy.utils.register_class(SNA_OT_Window_Open_F3Bce)
    bpy.utils.register_class(SNA_OT_Off_F6Fbf)
    bpy.utils.register_class(SNA_OT_On_F7884)
    bpy.utils.register_class(SNA_OT_Basic_Set_Up_5C085)
    bpy.utils.register_class(SNA_OT_Camra_62Ea3)
    bpy.utils.register_class(SNA_OT_Moddel_Modifier_Bones_21C98)
    bpy.utils.register_class(SNA_OT_Blend_Shapes_8Eb80)
    bpy.utils.register_class(SNA_PT_BLENDER_VT_17B29)
    
    # Register second addon classes
    bpy.utils.register_class(ANIM_OT_vtt_start)
    bpy.utils.register_class(ANIM_OT_vtt_stop)
    bpy.utils.register_class(ANIM_OT_vtt_reset_vowel)
    bpy.utils.register_class(ANIM_OT_vtt_reset_rest)
    bpy.utils.register_class(ANIM_PT_vtt)
    bpy.utils.register_class(VTTSettings)
    
    bpy.types.Scene.vtt = bpy.props.PointerProperty(type=VTTSettings)

def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    
    # Unregister first addon classes
    bpy.utils.unregister_class(SNA_OT_Window_Open_F3Bce)
    bpy.utils.unregister_class(SNA_OT_Off_F6Fbf)
    bpy.utils.unregister_class(SNA_OT_On_F7884)
    bpy.utils.unregister_class(SNA_OT_Basic_Set_Up_5C085)
    bpy.utils.unregister_class(SNA_OT_Camra_62Ea3)
    bpy.utils.unregister_class(SNA_OT_Moddel_Modifier_Bones_21C98)
    bpy.utils.unregister_class(SNA_OT_Blend_Shapes_8Eb80)
    bpy.utils.unregister_class(SNA_PT_BLENDER_VT_17B29)
    
    # Unregister second addon classes
    bpy.utils.unregister_class(ANIM_OT_vtt_start)
    bpy.utils.unregister_class(ANIM_OT_vtt_stop)
    bpy.utils.unregister_class(ANIM_OT_vtt_reset_vowel)
    bpy.utils.unregister_class(ANIM_OT_vtt_reset_rest)
    bpy.utils.unregister_class(ANIM_PT_vtt)
    bpy.utils.unregister_class(VTTSettings)
    
    del bpy.types.Scene.vtt